# Chess 3D > 2025-06-09 11:05pm
https://universe.roboflow.com/chess-bjkwh/chess-3d

Provided by a Roboflow user
License: MIT

