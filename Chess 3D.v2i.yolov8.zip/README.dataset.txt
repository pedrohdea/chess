# Chess 3D > 2025-06-07 3:54pm
https://universe.roboflow.com/chess-bjkwh/chess-3d

Provided by a Roboflow user
License: MIT

